package com.test;

public interface UserServiceBo {
    String sayHello(String name);  
    String sayHello2(String name);  
    
    String testPojo(Person person);
}
  