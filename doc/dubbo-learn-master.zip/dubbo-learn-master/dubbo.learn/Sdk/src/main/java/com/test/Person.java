package com.test;

public interface Person {

}
